## Release summary

This is the first attempted CRAN release of swirl 2.4.5.

## Test environments

* local macOS Sierra install, R 3.6.1
* Ubuntu 16.04 (on travis-ci), R 3.6.1, R 3.5.3, R-devel.
* win-builder (release)

## R CMD check results

There were no ERRORs, WARNINGs or NOTEs.